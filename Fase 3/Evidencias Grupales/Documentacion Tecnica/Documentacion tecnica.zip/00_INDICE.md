# Documentación técnica — Fase 3

**Base: versión 1.3, 31-10-2026. Revisión 1.4, 3-11-2026** (PDF, portada y Registro de revisión). Esta carpeta deja de ser una copia sin cambios de Fase 2. La fuente principal es el código local actual; no se certifica equivalencia con la rama remota ni configuración de producción.

- [PDF principal](Documento_Tecnico_Capstone.pdf)
- [Fuente LaTeX](Documento_Tecnico_Capstone.tex)
- [Arquitectura](secciones/01-arquitectura.tex): Supabase directo, funciones Edge, perfil, registro, roles y publicación.
- [Datos y UML](secciones/02-datos-uml.tex): línea base y extensiones, límites de los diagramas históricos.
- [RNF, pruebas e innovación](secciones/03-rnf-pruebas-docker-innovacion.tex): estados sin afirmar cumplimiento no medido; incluye la propuesta de ingresos de Fase 2 mediante promoción pagada para organizadores verificados (subsección 10.1) y la condición de uso no comercial de Vercel Hobby.

## Diagramas

Los diagramas 01–08 conservan fuente `.mmd` y salidas PDF/SVG. Los casos de uso y las clases son vistas conceptuales. Los diagramas 06 y 08 representan el modelo local del catálogo y de identidad y recuperación.

## Otros archivos de la carpeta

- [ZIP de entrega](Documentacion%20tecnica.zip): espejo 1:1 de esta carpeta (38 archivos), regenerar tras cada cambio.
- [Registro de revision.docx](Registro%20de%20revision.docx): bitácora de la revisión documental (v1.4, 3-11-2026).
- [Verificacion/](Verificacion/): huellas de fuentes y del original, control de páginas y resultado de la revisión.

## Recompilación

Desde esta carpeta:

```bash
pdflatex -halt-on-error -interaction=nonstopmode Documento_Tecnico_Capstone.tex
pdflatex -halt-on-error -interaction=nonstopmode Documento_Tecnico_Capstone.tex
```

Los fragmentos de `secciones/` no se compilan solos. Mantener fuentes y PDFs coherentes; excluir auxiliares y secretos de la entrega. El registro documental no prueba que los archivos estén en Git: registrar un commit autorizado y comprobarlo antes de enviar.
