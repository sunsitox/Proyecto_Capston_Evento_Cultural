# Documentación técnica — Fase 3

**Versión 1.3, 31-10-2026.** Esta carpeta deja de ser una copia sin cambios de Fase 2. La fuente principal es el código local actual; no se certifica equivalencia con la rama remota ni configuración de producción.

- [PDF principal](Documento_Tecnico_Capstone.pdf)
- [Fuente LaTeX](Documento_Tecnico_Capstone.tex)
- [Arquitectura](secciones/01-arquitectura.tex): Supabase directo, funciones Edge, perfil, registro, roles y publicación.
- [Datos y UML](secciones/02-datos-uml.tex): línea base y extensiones, límites de los diagramas históricos.
- [RNF, pruebas e innovación](secciones/03-rnf-pruebas-docker-innovacion.tex): estados sin afirmar cumplimiento no medido.
- [Respuesta a la rúbrica](../Respuesta%20a%20la%20evaluación.docx).

## Diagramas

Los diagramas 01 (arquitectura), 02 (componentes) y 04 (secuencia) se actualizan al flujo actual. Cada uno conserva fuente `.mmd` y salidas PDF/SVG. Los diagramas 03, 05, 06 y 07 se conservan como línea base conceptual/histórica; el ER no es una exportación del esquema remoto actual.

## Recompilación

Desde esta carpeta:

```bash
pdflatex -halt-on-error -interaction=nonstopmode Documento_Tecnico_Capstone.tex
pdflatex -halt-on-error -interaction=nonstopmode Documento_Tecnico_Capstone.tex
```

Los fragmentos de `secciones/` no se compilan solos. Mantener fuentes y PDFs coherentes; excluir auxiliares y secretos de la entrega. El registro documental no prueba que los archivos estén en Git: registrar un commit autorizado y comprobarlo antes de enviar.
